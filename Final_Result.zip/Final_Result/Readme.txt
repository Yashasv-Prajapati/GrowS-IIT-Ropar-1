ReadMe regarding results:-
1. 6 kml and 6 csv files regarding initial routes and routes after pickup points
2. Google Geocoding API couldn't detect many of the addresses provided by you, hence couldn't include in final solution
3. Have taken assumptions regarding number of vehicles equal to 50, number of bags of type 1 and type 2 equal to 50 and sku mapping equal to 10000 cm^3 for each object